% This script is to do the analysis of the delta^18 O time series obtained
% from the Greenland Ice-Core project

clear all
close all
tic
load GreenLandIceCore.mat Temp %load the delta^18 O time series
Temp=Temp(1:2:end);
T=1:length(Temp);
T=T/20;

%1 plot the raw data
figure
plot(T,Temp,'k-')
xlim([T(1),T(end)])
set(gca,'linewidth',1)
set(gcf, 'Color', 'white')
set(gca,'FontSize',14,'FontWeight','normal')
xlabel('T kyr','Interpreter','latex','FontSize',16)
ylabel('$\delta^{18}O$','Interpreter','latex','FontSize',16)
disp('Finish plot the raw data')
toc

%%% Hilbert methodology
%intrinsic mode function
imf=emdc(Temp);%EMD
figure
visuemd(imf,T)%show the imfs
set(gcf, 'Color', 'white')
xlabel('T kyr','Interpreter','latex','FontSize',16)


%calculating the Hilbert spectrum
[~,hs1,~,Fbin,Q]=hhsspectrumxM(imf,10,length(imf),4,0.25);
%in which 4 and 0.25 mean the orders of spectrum are from 0 to 4 with the
%interval of 0.25
hs1=bsxfun(@times,hs1,hs1(:,5).^-1);%normalize the spectra with order 1 (Q(5)=1)
Fbin=Fbin*20;%adjust the frequency according to your data sampling interval

figure
subplot(1,2,1)
loglog(Fbin,hs1(:,9),'ko')%plot the second-order spectrum
hold on
ylim([1e-1,1e1])
xlabel('$f\,$kyr$^{-1}$','Interpreter','latex','FontSize',16)
ylabel('$L_2(f)$','Interpreter','latex','FontSize',16)
xi=find(Fbin>0.1&Fbin<4);%choose a fitting range
[cf,coef]=PolyFitN(log10(Fbin(xi)),log10(hs1(xi,9)),1);
plot([1e-2,1e1],[1e-2,1e1].^cf.p1*10^cf.p2,'k-')

subplot(1,2,2)
loglog(Fbin,hs1(:,9)'.*Fbin.^-cf.p1*10^-cf.p2,'ko')
hold on
ylim([1e-1,1e1])
plot([1e-2,1e1],[1,1],'k--')
xlabel('$f\,$kyr$^{-1}$','Interpreter','latex','FontSize',16)
ylabel('comp.','Interpreter','latex','FontSize',16)

%scaling exponent
clear p p1
for i=1:length(Q)
    [cf,coef]=PolyFitN(log10(Fbin(xi)),log10(hs1(xi,i)),1);
    p(i,:)=-coef(1,:);
    [cf,coef]=PolyFitN(log10(hs1(xi,17)),log10(hs1(xi,i)),1);
    p1(i,:)=coef(1,:);
end


figure
subplot(1,2,1)
errorbar(Q,p(:,1),p(:,2),'o')
ylim([-0.5,1.5])
hold on
plot(Q,Q/3)
xlabel('$q$')
ylabel('$\zeta(q)$','Interpreter','latex','FontSize',16)
subplot(1,2,2)
errorbar(Q,p1(:,1),p1(:,2),'ko')
ylim([-0.5,1.5])
hold on
plot(Q,Q/3)
xlabel('$q$')
ylabel('$\zeta_E(q)$','Interpreter','latex','FontSize',16)
modelFun1=@(p,x) x/3-p(1)/2*(x.^2/9-x/3)
starVal=[0];
[BETA1,R,J]=nlinfit(Q(5:end),p1(5:end,1)',modelFun1,starVal);
plot(Q,modelFun1(BETA1,Q),'r')

