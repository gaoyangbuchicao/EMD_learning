function [TT,hs1,hs2,Fbin,Q]=hhsspectrumxM(imf,NF,NT,q,dq)
% [TT,hs,Fbin]=hhsspectrumx(imf,NF,NT,q,dq);
% This function is to estimate the Hilbert spectrum along the time axis
% Input
% imf is the IMF from EMD algorithm
% NF is the number of frequency bin each decade
% NT is the length of each time bin
% q is the maximum statistical order
% dq is the increment of the statistical order
% Output
% TT is the time axis 
% hs is the calcuated qth-order Hilbert spectrum
% Fbin is the frequency bin
% 
% Written by Yongxiang HUANG 29-10-2016
% 
% see also: hhsp2

if nargin~=5
    error('Five input!')
end

Nimf=size(imf);
T=1:Nimf(2)-2;

[instf,~]=instantaneous2(imf);% exclude the residual
% instf=reshape(instf,Nimf(2),Nimf(1)-1); % reshape the instantaneous frequency,
% insta=reshape(insta,Nimf(2),Nimf(1)-1);
% insta=insta.^2;
T=round(T/NT+0.5);
TT=unique(T);
Fb=1/NF;
% BINF=log10(2/Nimf(2)):Fb:log10(0.5);
BINF=-log10(0.5):Fb:-log10(2/Nimf(2));
BINF=-BINF(end:-1:1);
instf=log10(instf);
instf=fix((instf-BINF(1))/Fb+0.5);
NT=length(TT);
NW=length(BINF);
Q=0:dq:q;
NQ=length(Q);
hs1=zeros(NT,NW,NQ);
hs2=hs1;
xi=find(isnan(instf)==1);
instf(xi)=0;
insta=imf(1:end-1,:);
tmp1=abs(insta).^Q(1);
tmp2=abs(insta).^dq;

insta=gradient(insta(1:end,:));
tmp11=abs(insta).^Q(1);
tmp22=abs(insta).^dq;

for iq=1:NQ
    for i=1:Nimf(1)-1
        for j=1:Nimf(2)-2
            if instf(i,j)<1 || instf(i,j)>NW
                continue;
            end
            hs1(T(j),instf(i,j),iq)=hs1(T(j),instf(i,j),iq)+tmp1(i,j);
            hs2(T(j),instf(i,j),iq)=hs2(T(j),instf(i,j),iq)+tmp11(i,j);

        end
    end
    tmp1=tmp1.*tmp2;
    tmp11=tmp11.*tmp22;

end
Fbin=10.^BINF;
hs1=squeeze(hs1);
hs2=squeeze(hs2);


function [instf,insta] = instantaneous2(data,fs)
% [instf,insta] = instantaneous(imf)
% This function is to get the instantaneous frequency and amplitude
% Input
% imf is the imf mode from EMD
% fs is the sampling frequency
% Output
% instf is the instantaneous frequency
% insta is the instantaneous moudulation
% 
% See also mrgnllog mrgnlrslog

if nargin==1
    fs=1;
end

[knb,npt] = size(data);
if knb>npt
    data=data';
    [knb,npt] = size(data);
end

% for i=1:knb
%     data(i,:)=data(i,:)-mean(data(i,:));
% end

data=hilbtmm(data')'; % get the analysitical siginal
%f=zeros(knb,npt-2);
if knb>1
    instf=zeros(knb-1,npt-2);
    for i=1:knb-1 % exclude the residual
        tmp=instfreq(data(i,:)')'; % Get the instantaneous frequency
        instf(i,:)=tmp;
    end
    Nf=size(instf);
    insta=abs(data(1:end-1,2:end-1));% get the amplitude
    
end
instf=instf*fs;

