
function imf=emdf(x)
mx=mean(x);
x=x-mx;

cl=class(x);
if strcmp(cl,'single')
    x=double(x);
end
imf=emdc(x);
xi=find(isnan(imf)==1, 1);
if ~isempty(xi)
    imf=emd(x);
end


Mx=max(abs(x));
Mi=max(max(imf));

if Mi>2*Mx
    imf=emd(x);
end

imf(end,:)=imf(end,:)+mx;
